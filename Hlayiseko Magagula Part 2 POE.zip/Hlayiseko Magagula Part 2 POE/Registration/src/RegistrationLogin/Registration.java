
package RegistrationLogin;

import javax.swing.JOptionPane;
// declaring our string data types
public class Registration {
    
     static String firstName;
     static String userName;
     static String surname;
     static String password;
 // put the scanner we have imported to use and also declaring userDetails method   
    public static void userDetails(){
         boolean validDetails = false; 

        while (!validDetails) { 
        
        firstName =  JOptionPane.showInputDialog("Please enter you first name");
        
        surname = JOptionPane.showInputDialog("Please enter your surname");
                
        userName = JOptionPane.showInputDialog("Please enter your userName");
       
        password = JOptionPane.showInputDialog("Please enter your password");
          if (firstName == null || firstName.isEmpty() || 

                surname == null || surname.isEmpty() || 

                userName == null || userName.isEmpty() || 

                password == null || password.isEmpty()) { 

                JOptionPane.showMessageDialog(null, "All fields are required. Please try again."); 

            } else { 
               validDetails = true; 
       
          }
        }
    }
    
    
        
        
public static void main(String[] args) {
       userDetails();
Login logObject = new Login(); 

logObject.checkUserName();
logObject.checkPasswordComplexity();
UserInfo info=new UserInfo();
info.WelcomeNote();
                    
                    

                } 

} 
                    


        

   
